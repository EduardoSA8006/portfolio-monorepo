#!/usr/bin/env bash
# Builds a clean release ZIP from Git-tracked files only.
# Usage:
#   scripts/build-release-zip.sh [git-ref] [output-zip]

set -euo pipefail

if [ "$#" -gt 2 ]; then
    echo "Usage: $0 [git-ref] [output-zip]" >&2
    exit 1
fi

ref="${1:-HEAD}"
safe_ref="${ref//\//-}"
output_zip="${2:-dist/portfolio-backend-${safe_ref}.zip}"
prefix="portfolio-backend/"

git rev-parse --verify "${ref}^{commit}" >/dev/null
mkdir -p "$(dirname "$output_zip")"

git archive \
    --worktree-attributes \
    --format=zip \
    --prefix="$prefix" \
    --output="$output_zip" \
    "$ref"

echo "Wrote clean release ZIP to $output_zip"
